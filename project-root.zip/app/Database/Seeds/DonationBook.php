<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class DonationBook extends Seeder
{
    public function run()
    {
        //
    }
}
